Fig1a_part2.jpg is the original embedded physical-illustration panel extracted without image editing from the author-supplied Manuscript_red(20261015-114628).pdf, page 4.
It is used only for Figure 1(a). Numerical calculations do not read this image.
Preserve the artwork provenance and existing rights when distributing the source.
