import argparse,json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from model import *
from algebraic_check import eliminate
from figures import save,dump,panel,COL

def run(part,out):
 if part==1:
  p=parameters(1,True);a=drives(p);norm=np.linalg.norm(a);cases=[]
  for ph in np.linspace(0,np.pi,7):cases.append((f'phase {ph:.3f}',dict(p,drive_override=[abs(a[0]),abs(a[1])*np.exp(1j*ph)])))
  cases.extend([('m only',dict(p,drive_override=[norm,0])),('n only',dict(p,drive_override=[0,norm])),('zero Kerr',dict(p,K=0)),('no phonon',dict(p,gmb=0,gnb=0)),('single magnon',dict(p,gn=0,gnb=0,drive_override=[norm,0]))])
  records=[]
  for name,q in cases:
   # Degenerate limiting cases can have identically zero eliminated factors.
   if name in ['no phonon','single magnon']:rr=roots(q,(5,20),24)
   else:rr,_=eliminate(q)
   margins=[max(np.linalg.eigvals(jacobian(reconstruct(n,q),q)).real) for n in rr];records.append(dict(case=name,stable=sum(v<-1e-8 for v in margins),unstable=sum(v>1e-8 for v in margins),roots=[list(n) for n in rr]))
  (out/'additional_controls.json').write_text(json.dumps(records,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)));print(records)
 else:
  p=parameters(2);d=np.linspace(-1,2,3001);fig,ax=plt.subplots(2,2,figsize=(10,7));records=[]
  for k,(name,q) in enumerate([('Full',p),('No mechanics',dict(p,gmb=0,gnb=0)),('No Kerr',dict(p,K=0)),('No cross drive',dict(p,xi=0)),('No second mechanical channel',dict(p,gnb=0))]):
   u=stationary(q);margin=max(np.linalg.eigvals(jacobian(u,q)).real);records.append(dict(case=name,margin=margin));z=np.array([response(u,q,x)[0] for x in d]);ax[0,0].plot(d,abs(z)**2,c=COL[k],label=name,lw=1)
  ax[0,0].legend(fontsize=8);ax[0,0].set_ylabel(r'$|t_p|^2$')
  # Actual independent redistribution in an explicitly asymmetric assumed geometry.
  p.update(bm=.25,bn=.2,phase_m=.2,phase_n=-.15,matched_norm=2.)
  for k,xi in enumerate([0,.8,1.6]):
   q=dict(p,xi=xi);u=None
   for dr in np.linspace(0,q['drive'],101):u=stationary(dict(q,drive=dr),u)
   z=np.array([response(u,q,x)[0] for x in d]);ax[0,1].plot(d,abs(z)**2,c=COL[k],label=f'ξ={xi}',lw=1);records.append(dict(case=f'asymmetric matched norm xi={xi}',margin=max(np.linalg.eigvals(jacobian(u,q)).real),norm=float(np.vdot(drives(q),drives(q)).real)))
  ax[0,1].legend(fontsize=8);ax[0,1].set_ylabel(r'$|t_p|^2$');ax[0,1].set_title('Asymmetric overlaps, fixed drive norm',fontsize=10)
  # Pulse calculation at a selected stable delay point of original coupling scan.
  p=parameters(2);p.update(ex=.9,rm=.008,rn=.008,damp=.003,damp_n=.003,phase_m=np.pi,phase_n=-np.pi,xi=1.5,K=6)
  best=None
  for s in np.linspace(0,30,501):
   q=dict(p,gm=.45*np.sqrt(.5+s));u=stationary(q);t,tau=response(u,q,1.95);margin=max(np.linalg.eigvals(jacobian(u,q)).real)
   if margin<-1e-8 and (best is None or tau>best[0]):best=(tau,q,u,t,s)
  tau,q,u,t,s=best;sigma=.001;freq=np.linspace(-.05,.05,4096,endpoint=False);env=np.exp(-freq**2/(4*sigma**2));trans=np.array([response(u,q,1.95+x)[0] for x in freq]);ts=np.fft.fftshift(np.fft.fftfreq(len(freq),d=freq[1]-freq[0]))*2*np.pi
  # e^{-i omega t}: FFT, not IFFT.
  inp=np.fft.fftshift(np.fft.fft(np.fft.ifftshift(env)));oup=np.fft.fftshift(np.fft.fft(np.fft.ifftshift(env*trans)));ii=abs(inp)**2;oo=abs(oup)**2;peakshift=ts[np.argmax(oo)]-ts[np.argmax(ii)];centroid=np.sum(ts*oo)/sum(oo)-np.sum(ts*ii)/sum(ii);energy=float(np.sum(oo)/np.sum(ii))
  ax[1,0].plot(ts,ii/max(ii),label='Input',c=COL[1]);ax[1,0].plot(ts,oo/max(oo),label='Output (normalized)',c=COL[2]);ax[1,0].set(xlim=(-1800,1800),xlabel=r'$\kappa_c t$',ylabel='Normalized pulse intensity');ax[1,0].legend(fontsize=8)
  xx=np.linspace(-.04,.04,2001);zz=np.array([response(u,q,1.95+x)[0] for x in xx]);ax[1,1].plot(xx,abs(zz)**2,c=COL[1]);ax[1,1].axvspan(-3*sigma,3*sigma,color=COL[2],alpha=.2);ax[1,1].set(xlabel=r'$(\delta-1.95)/\kappa_c$',ylabel=r'$|t_p|^2$');ax[1,1].set_title('Pulse spectrum within shaded interval',fontsize=10)
  for a,l in zip(ax.flat,'abcd'):panel(a,l)
  ax[0,0].set_xlabel(r'$\delta/\kappa_c$');ax[0,1].set_xlabel(r'$\delta/\kappa_c$');fig.tight_layout();save(fig,out,'Validation2')
  shifted=np.interp(ts-centroid,ts,ii,left=0,right=0);shape_error=float(np.sqrt(np.mean((oo/max(oo)-shifted/max(shifted))**2)))
  records.append(dict(case='pulse',s=float(s),delay=float(tau),T=float(abs(t)**2),centroid_delay=float(centroid),energy_transmission=energy,normalized_shape_RMS=shape_error,sigma=sigma,margin=float(max(np.linalg.eigvals(jacobian(u,q)).real))))
  (out/'additional_controls.json').write_text(json.dumps(records,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)));print(records)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--part',type=int,required=True);ap.add_argument('--out',required=True);a=ap.parse_args();run(a.part,Path(a.out))
