"""Exact supplied apparatus artwork and equal-sized vector model panel."""
from pathlib import Path
import argparse
import subprocess
import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle


def run(part, out):
    out.mkdir(exist_ok=True, parents=True)
    plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'DejaVu Serif'],
                         'mathtext.fontset': 'stix', 'pdf.fonttype': 42})
    themes = {
        1: dict(m='#C8511B', n='#246DA7', mech='#247C52', cav='#A2780B',
                mf='#FCE8DC', nf='#E4F1FB', bf='#E5F3E8', cf='#FFF1C9'),
        2: dict(m='#7850AA', n='#008985', mech='#3264B5', cav='#B14D78',
                mf='#EDE3F8', nf='#DDF4EF', bf='#E2ECFC', cf='#F9E1EC')}
    t = themes[part]
    ink, gray = '#253044', '#737B84'
    artwork = Path(__file__).resolve().parent / 'assets' / f'Fig1a_part{part}.jpg'
    if not artwork.is_file():
        raise FileNotFoundError(artwork)
    meta = fitz.Pixmap(artwork)
    ratio = meta.height / meta.width
    # Both panels use the original image's landscape aspect ratio, without cropping.
    fig = plt.figure(figsize=(12, 12 * ratio))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, 12), ylim=(0, 6.6))
    ax.axis('off')

    def text(x, y, s, fs=19, color=ink, **kw):
        ax.text(x, y, s, fontsize=fs, ha=kw.pop('ha', 'center'),
                va=kw.pop('va', 'center'), color=color, **kw)

    def box(x, y, w, h, s, face='white', edge=ink, fs=19):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle='round,pad=.025,rounding_size=.065',
                     fc=face, ec=edge, lw=1.9, zorder=3))
        text(x+w/2, y+h/2, s, fs, zorder=4)

    def arrow(a, b, color=ink, both=False, style='-', lw=2.1, rad=0):
        ax.annotate('', b, a, arrowprops=dict(
            arrowstyle='<->' if both else '->', color=color, lw=lw,
            linestyle=style, connectionstyle=f'arc3,rad={rad}',
            shrinkA=3, shrinkB=3), zorder=2)

    # Coherent drive network, separated spatially from the mode couplings.
    box(4.69, 6.02, 2.62, .44, 'Microwave source', fs=19)
    arrow((6, 6.0), (6, 5.65))
    ax.add_patch(Circle((6, 5.60), .07, fc=ink, ec=ink))
    text(7.02, 5.83, '50:50 splitter', 17)
    ax.plot([5.92, 2.4, 2.4], [5.60, 5.60, 5.26], color=t['m'], lw=2.1)
    ax.plot([6.08, 9.6, 9.6], [5.60, 5.60, 5.52], color=t['n'], lw=2.1)
    box(9.08, 5.20, 1.04, .32, r'$\pi$ shift', edge=t['n'], fs=18)
    arrow((2.4, 5.26), (2.4, 5.02), t['m'])
    arrow((9.6, 5.19), (9.6, 5.02), t['n'])
    text(1.65, 5.30, r'$\varphi_1=0$', 19, t['m'])
    text(10.76, 5.35, r'$\varphi_2=\pi$', 19, t['n'])
    box(1.16, 4.47, 2.48, .51, r'Antenna 1: $+\Omega$', t['mf'], t['m'], 20)
    box(8.36, 4.47, 2.48, .51, r'Antenna 2: $-\Omega$', t['nf'], t['n'], 20)

    # Arrowheads terminate at the driven mode. Dashed paths are external
    # antenna projections, not a direct magnon-exchange interaction.
    arrow((2.4, 4.44), (2.4, 3.36), t['m'])
    arrow((9.6, 4.44), (9.6, 3.36), t['n'])
    arrow((3.40, 4.44), (8.65, 3.36), t['m'], style='--')
    arrow((8.60, 4.44), (3.35, 3.36), t['n'], style='--')
    text(1.87, 3.96, r'$\beta_{m1}$', 22, t['m'])
    text(10.17, 3.96, r'$\beta_{n2}$', 22, t['n'])
    text(4.69, 4.38, r'$\xi\beta_{n1}$', 21, t['m'])
    text(7.31, 4.38, r'$\xi\beta_{m2}$', 21, t['n'])

    box(1.20, 2.72, 2.40, .60, r'$m$: Kerr $K_0$', t['mf'], t['m'], 21)
    box(8.40, 2.72, 2.40, .60, r'$n$: $K_{n0}\simeq0$', t['nf'], t['n'], 21)
    text(6, 3.01, 'One YIG sphere\nStatic bias $B_0$', 19, linespacing=1.3)
    arrow((1.17, 3.02), (.45, 3.02), gray)
    text(.79, 3.37, r'$r_m$', 20, gray)
    arrow((10.83, 3.02), (11.55, 3.02), gray)
    text(11.21, 3.37, r'$r_n$', 20, gray)

    box(4.92, 1.56, 2.16, .57, 'Cavity $c$' if part == 1 else 'Cavity $a$',
        t['cf'], t['cav'], 21)
    arrow((3.64, 2.74), (4.93, 2.13), ink, both=True)
    arrow((8.36, 2.74), (7.07, 2.13), ink, both=True)
    text(4.05, 2.21, r'$g_m$', 23)
    text(7.95, 2.21, r'$g_n$', 23)
    arrow((7.12, 1.84), (7.85, 1.84), gray)
    text(7.48, 1.48, r'$r_c$', 20, gray)

    if part == 1:
        box(4.90, .36, 2.20, .57, 'Shared mode $b$', t['bf'], t['mech'], 20)
        arrow((2.40, 2.68), (4.86, .70), t['mech'], both=True)
        arrow((9.60, 2.68), (7.14, .70), t['mech'], both=True)
        text(2.91, 1.43, r'$g_{mb}^{(0)}$', 23, t['mech'])
        text(9.09, 1.43, r'$g_{nb}^{(0)}$', 23, t['mech'])
        text(6, 1.15, 'No cavity pump', 17)
        arrow((7.14, .64), (7.87, .64), gray)
        text(8.25, .64, r'$\gamma_b$', 20, gray)
    else:
        for x, lab in [(2.4, 'm'), (9.6, 'n')]:
            box(x-1.0, .36, 2.0, .57, r'Mode $b_'+lab+'$', t['bf'], t['mech'], 20)
            arrow((x, 2.68), (x, .97), t['mech'], both=True)
            text(x + (-.68 if lab == 'm' else .68), 1.79,
                 r'$g_{'+lab+r'b}^{(0)}$', 23, t['mech'])
            start, end, tx = ((x-1.04, .64), (x-1.79, .64), x-1.4) if lab=='m' else ((x+1.04, .64), (x+1.79, .64), x+1.4)
            arrow(start, end, gray)
            text(tx, 1.00, r'$\gamma_{b'+lab+'}$', 19, gray)
        arrow((5.80, .45), (5.80, 1.52), ink)
        arrow((6.20, 1.52), (6.20, .45), ink)
        text(4.75, .77, 'Weak probe', 18)
        text(7.40, .77, 'Output', 18)
        text(6, .18, 'Monitored cavity port', 17)

    technical = out / 'Fig1b.pdf'
    fig.savefig(technical)
    plt.close(fig)
    # Equal rectangular panels, stacked to retain readable labels at journal size.
    w, gap, label_h = 864., 24., 24.
    h = w*ratio
    d = fitz.open()
    page = d.new_page(width=w+32, height=2*h+2*label_h+gap+12)
    a_rect = fitz.Rect(16, label_h, 16+w, label_h+h)
    b_rect = fitz.Rect(16, 2*label_h+h+gap, 16+w, 2*label_h+2*h+gap)
    page.insert_text((16, 18), '(a)', fontname='Times-Bold', fontsize=22)
    page.insert_image(a_rect, stream=artwork.read_bytes(), keep_proportion=True)
    page.insert_text((16, b_rect.y0-6), '(b)', fontname='Times-Bold', fontsize=22)
    bdoc = fitz.open(technical)
    page.show_pdf_page(b_rect, bdoc, 0, keep_proportion=True)
    tmp = out / 'Fig1.tmp.pdf'
    d.save(tmp, garbage=4, deflate=True)
    d.close(); bdoc.close(); tmp.replace(out/'Fig1.pdf')
    d = fitz.open(out/'Fig1.pdf')
    d[0].get_pixmap(matrix=fitz.Matrix(1.1, 1.1)).save(out/'Fig1.png')
    d.close()
    eps_tmp = out/'Fig1.tmp.eps'
    subprocess.run(['pdftops', '-eps', str(out/'Fig1.pdf'), str(eps_tmp)], check=True)
    if not eps_tmp.read_bytes().rstrip().endswith(b'%%EOF'):
        raise RuntimeError('Incomplete EPS export')
    eps_tmp.replace(out/'Fig1.eps')
    technical.unlink()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--part', type=int, choices=[1, 2], required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    run(args.part, Path(args.out))
