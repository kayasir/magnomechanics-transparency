import json
import numpy as np
import matplotlib.pyplot as plt
from model import *

def p2(out,quality):
 from figures import save,dump,panel,COL,STYLES
 diagnostics=[];N=3601 if quality=='final' else 1201;ds=np.linspace(-2.5,3.5,N)
 def continuation(p,key,values):
  u=None;previous=0.;result=[]
  for v in values:
   for vv in np.linspace(previous,v,101):u=stationary(dict(p,**{key:vv}),u)
   pp=dict(p,**{key:v});margin=max(np.linalg.eigvals(jacobian(u,pp)).real);result.append((pp,u.copy(),margin));previous=v
  return result
 def draw(ax,states,key,phase=False,detail=False):
  for j,(p,u,margin) in enumerate(states):
   z=np.array([response(u,p,d)[0] for d in ds]);val=np.angle(z) if phase else abs(z)**2
   diagnostics.append(dict(figure='spectra',parameter=key,value=p[key],margin=margin,nm=float(sum(u[2:4]**2)),nn=float(sum(u[4:6]**2)),state=u.tolist(),residual=float(max(abs(rhs(u,p)))),eigenvalues=np.column_stack([np.linalg.eigvals(jacobian(u,p)).real,np.linalg.eigvals(jacobian(u,p)).imag]).tolist(),parameters=p))
   if margin>=-1e-8:continue
   shown=val.copy()
   if phase:shown[np.r_[False,np.abs(np.diff(shown))>np.pi]]=np.nan
   ax.plot(ds,shown,c=COL[j],lw=1.9,ls=STYLES[j],label=f'{p[key]:g}')
   dump(out,f'spectrum_{key}_{p[key]}_'+('phase' if phase else 'T'),np.c_[ds,z.real,z.imag,val],'delta,t_real,t_imag,value')
  ax.set(xlabel=r'$\delta/\kappa_c$',ylabel=r'$\arg(t_p)$ (rad)' if phase else r'$T_p=|t_p|^2$',xlim=((.45,1.35) if key=='K' else (.25,2.5)) if detail else (-2.5,3.5));ax.legend(title=key,fontsize=8,ncol=2,framealpha=.65)

 p=parameters(2);gm=continuation(p,'gm',np.linspace(0,2,6));gn=continuation(p,'gn',np.linspace(0,2,6))
 fig,ax=plt.subplots(2,2,figsize=(10,7))
 for a,st,k,ph,l in zip(ax.flat,[gm,gn,gm,gn],['gm','gn']*2,[False,False,True,True],'abcd'):draw(a,st,k,ph);panel(a,l)
 fig.tight_layout();save(fig,out,'Fig2')
 for num,key,vals in [(3,'K',[0,2,4,6,9,12]),(4,'xi',[0,1,3,4,6,8])]:
  st=continuation(p,key,vals);fig,ax=plt.subplots(2,2,figsize=(10,6.8))
  for a,ph,detail,l in zip(ax.flat,[False,True,False,True],[False,False,True,True],'abcd'):draw(a,st,key,ph,detail);panel(a,l)
  fig.tight_layout();save(fig,out,f'Fig{num}')
 # Fano maps: continue in detuning from dc=0 outwards, as original notebooks.
 det=np.linspace(-4,4,801 if quality=='final' else 401);cavs=np.linspace(-4,4,121);fig,ax=plt.subplots(2,2,figsize=(10,7.4));unst=[]
 for a,(key,v),l in zip(ax.flat,[('K',0),('K',12),('xi',0),('xi',8)],'abcd'):
  st=continuation(p,key,[v]);pp,u,_=st[0];center=len(cavs)//2;states={center:u};arr=np.full((len(cavs),len(det)),np.nan);rows=[]
  for direction in [-1,1]:
   old=u.copy()
   for idx in range(center,(-1 if direction==-1 else len(cavs)),direction):
    start=cavs[idx-direction] if idx!=center else 0
    for dc in np.linspace(start,cavs[idx],9):old=stationary(dict(pp,dc=dc),old)
    states[idx]=old.copy()
  for idx,dc in enumerate(cavs):
   qq=dict(pp,dc=dc);uu=states[idx];margin=max(np.linalg.eigvals(jacobian(uu,qq)).real);rows.append([dc,margin,*uu])
   if margin<-1e-8:arr[idx]=[abs(response(uu,qq,d)[0])**2 for d in det]
  im=a.pcolormesh(det,cavs,arr,vmin=0,vmax=1,cmap='YlOrBr_r',shading='auto',rasterized=True);a.set(xlabel=r'$\delta/\kappa_c$',ylabel=r'$\Delta_c/\kappa_c$',title='');a.text(.98,.97,('$\\widetilde K$' if key=='K' else '$\\xi$')+f' = {v:g}',transform=a.transAxes,ha='right',va='top',fontsize=13,bbox=dict(facecolor='white',edgecolor='none',pad=1.5));panel(a,l);unst.append(dict(parameter=key,value=v,unstable_rows=sum(np.array(rows)[:,1]>=-1e-8)))
  dump(out,f'fano_{key}_{v}_states',rows,'dc,margin,'+','.join('u'+str(i) for i in range(10)));dump(out,f'fano_{key}_{v}',np.c_[np.repeat(cavs,len(det)),np.tile(det,len(cavs)),arr.ravel()],'dc,delta,T')
 fig.subplots_adjust(wspace=.25,hspace=.35,right=.9);fig.colorbar(im,ax=ax,label=r'$|t_p|^2$',fraction=.03);save(fig,out,'Fig5')
 # Exact interpretation of legacy gd8: bare-coupling coordinate, not input power.
 fig,ax=plt.subplots(2,2,figsize=(10,7.2));maxima=[]
 for a,(channel,key,delta),l in zip(ax.flat,[('gm','K',1.95),('gm','xi',1.75),('gn','K',1.85),('gn','xi',1.75)],'abcd'):
  base=parameters(2);base.update(ex=.9,rm=.008,rn=.008,damp=.003,damp_n=.003,xi=1.5,K=.5,phase_m=np.pi,phase_n=-np.pi)
  for j,v in enumerate(np.linspace(0,6,6)):
   pp=dict(base,**{key:v,channel:.45*np.sqrt(.5)});u=None
   # turn on drive adiabatically at each curve's left endpoint
   for dr in np.linspace(0,pp['drive'],101):u=stationary(dict(pp,drive=dr),u)
   rows=[]
   for coord in np.linspace(0,30,501):
    qq=dict(pp,**{channel:.45*np.sqrt(.5+coord)});u=stationary(qq,u);margin=max(np.linalg.eigvals(jacobian(u,qq)).real);t,tau=response(u,qq,delta);rows.append([coord,qq[channel],tau,abs(t)**2,margin,*u])
   rows=np.array(rows);valid=rows[:,4]<-1e-8;vals=rows[:,2].copy();vals[~valid]=np.nan;a.plot(rows[:,0],vals,c=COL[j],lw=1.9,ls=STYLES[j],label=f'{v:g}');dump(out,f'delay_{channel}_{key}_{v}',rows,'s,g,tau,T,margin,'+','.join('u'+str(i) for i in range(10)))
   if np.any(valid):
    i=np.nanargmax(vals);maxima.append(dict(channel=channel,control=key,value=v,s=rows[i,0],delay=rows[i,2],T=rows[i,3],margin=rows[i,4]))
  a.set(xlabel=r'$s_'+('m' if channel=='gm' else 'n')+r'=(g/g_{\rm ref})^2-1/2$',ylabel=r'$\kappa_c\tau_g$',title=f'{channel}, δ = {delta:g}');panel(a,l);a.legend(title=key,ncol=3,framealpha=.65,fontsize=8)
 fig.tight_layout();save(fig,out,'Fig6')
 # genuine common-source power sweep, recomputing both channels
 fig,ax=plt.subplots(1,3,figsize=(12,3.6));power=[]
 for xi,col in [(0,COL[1]),(.25,COL[2]),(1.5,COL[4])]:
  pp=parameters(2);pp.update(xi=xi,phase_m=np.pi,phase_n=-np.pi);u=None;rows=[]
  for P in np.linspace(.05,5,201):
   qq=dict(pp,drive=.12*np.sqrt(P));u=stationary(qq,u);ev=max(np.linalg.eigvals(jacobian(u,qq)).real);t,tau=response(u,qq,.6);rows.append([P,abs(t)**2,tau,ev,*u])
  rows=np.array(rows);mask=rows[:,3]<-1e-8
  for a,k in zip(ax,[1,2,3]):a.plot(rows[:,0],np.where(mask,rows[:,k],np.nan),c=col,label=f'ξ={xi}')
  dump(out,f'true_power_{xi}',rows,'P_over_P0,T,tau,margin,'+','.join('u'+str(i) for i in range(10)))
 for a,lab,l in zip(ax,[r'$|t_p|^2$',r'$\kappa_c\tau_g$',r'$\max\Re\lambda/\kappa_c$'],'abc'):a.set(xlabel=r'$P/P_0$',ylabel=lab);panel(a,l)
 ax[0].legend(fontsize=8);fig.tight_layout();save(fig,out,'Validation1')
 (out/'summary.json').write_text(json.dumps(dict(spectra=diagnostics,fano=unst,delay_maxima=maxima),indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)))
