# Verification of source version 8.0.0

The numerical source was tested on Python 3.12.14 with the pinned dependency versions. The scientific validation and control calculations were executed for release 6. The corresponding numerical modules are unchanged in releases 7 and 8. This separate package changes the launcher and paper-specific documentation; its numerical solver and plotting modules remain byte-identical to the combined version-8 source. The existing scientific checks are not described as newly rerun for this packaging step.

The separate launcher was checked to dispatch all six stages to the correct paper with final plotting quality. All Python files were syntax-checked and all local source dependencies and the corresponding Figure 1(a) asset are included. Outputs are generated locally and are not bundled as precomputed data.

At all twelve Kerr/cross-drive line-spectrum settings, analytic susceptibilities and the complete real-Jacobian response agree within 5e-15 on 1001 frequencies. Full-state residuals are below 4e-15. Each setting has one stable root; xi=8 additionally has two unstable physical roots. The zero-drive state at xi=1 is handled explicitly. Independent pulse-moment quadrature on three grids gives centroid delay 30.44432792 and transmitted-energy fraction 0.4612855353, consistent with the time-domain pulse calculation. Figure 6 is a bare-coupling scan; the source-power control is separate. These selected-point checks do not constitute a global stability atlas.

The scientific supplement defines the checks and their physical limits. Device-calibrated overlap profiles are not supplied. Pixel appearance can vary with renderer and fonts.
